package com.br.maxima.model;

public enum OrderStatus {
    PAID
}
