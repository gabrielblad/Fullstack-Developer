package com.br.maxima.repository;

import com.br.maxima.model.OrderProduct;
import com.br.maxima.model.OrderProductPK;
import org.springframework.data.repository.CrudRepository;

public interface OrderProductRepository extends CrudRepository<OrderProduct, OrderProductPK> {
}
