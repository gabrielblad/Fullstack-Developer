package com.br.maxima.service;

import com.br.maxima.model.OrderProduct;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@Validated
public interface OrderProductService {

    OrderProduct create(@NotNull(message = "selecione um produto para fazer o pedido") @Valid OrderProduct orderProduct);
}
